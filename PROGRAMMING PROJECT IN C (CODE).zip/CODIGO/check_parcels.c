//
// Created by danie on 17/04/2023.
//
#include "check_parcels.h"

int control_production(int prod)
{
    int num = prod;

    do
    {
        if(num == 1 || num == 2 || num == 3)
        {
            return num;
        }
        else
        {
            printf("\nThat is not a valid production, try again...\n");
            printf("\nEnter the parcel's production: ");
            scanf("%d", &num);
        }
    }
    while(1);

    return 0;
}

float control_price(float price)
{
    float pri = price;
    char basura;

    do
    {
        if(pri > 0 && pri < 500)
        {
            return pri;
        }
        else
        {
            printf("\nThat is not a valid price, try again...\n");
            printf("\nEnter the parcel's price per unit: ");
            scanf("%c", &basura);
            scanf("%f", &pri);
        }
    }
    while(1);

    return 0;
}

int control_num_tools(int num_tools)
{
    int tools = num_tools;

    do
    {
        if(tools > 0 && tools < 11)
        {
            return tools;
        }
        else
        {
            printf("\nThat is not a valid tool number, try again...\n");
            printf("\nEnter the parcel's required tools number: ");
            scanf("%d", &tools);
        }
    }
    while(1);

    return 0;
}

int control_tool_cat(int cats)
{
    int tools = cats;
    char basura;

    do
    {
        if(tools > 0 && tools < 8)
        {
            return tools;
        }
        else
        {
            printf("\nThat is not a valid cat, try again...\n");
            printf("\nEnter the tool's category: ");
            scanf("%c", &basura);
            scanf("%d", &tools);
        }
    }
    while(1);

    return 0;
}

int control_tool_operation(int oper)
{
    int tools = oper;

    do
    {
        if(tools == 0 || tools == 1)
        {
            return tools;
        }
        else
        {
            printf("\nThat is not a valid input, try again...\n");
            printf("\nEnter the tool's operation: ");
            scanf("%d", &tools);
        }
    }
    while(1);

    return 0;
}

int control_fert_inf(int fert_inf)
{
    int tools = fert_inf;

    do
    {
        if(tools == 0 || tools == 1)
        {
            return tools;
        }
        else
        {
            printf("\nThat is not a valid input, try again...\n");
            printf("\nEnter if fertilizer is inflammable?: ");
            scanf("%d", &tools);
        }
    }
    while(1);

    return 0;
}