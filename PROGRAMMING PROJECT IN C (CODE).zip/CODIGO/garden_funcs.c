//
// Created by danie on 12/04/2023.
//
#include "garden_funcs.h"
#include "shrublib.h"

Garden initialize_garden()
{
    int option_rows = 0, option_cols = 0;

    printf("\nInitializing garden...\n");

    do
    {
        printf("\nWith how many rows do you want to place your garden? ");
        int result = scanf("%d", &option_rows);

        if(result != 1 || option_rows < 1)
        {
            printf("\nThat is not a valid number. Please try again.\n");
        }
    }
    while(option_rows < 1);

    do
    {
        printf("\nWith how many columns do you want to place your garden? ");
        int result = scanf("%d", &option_cols);

        if(result != 1 || option_cols < 1)
        {
            printf("\nThat is not a valid number. Please try again.\n");
        }
    }
    while(option_cols < 1);

    Garden garden = create_garden(option_rows, option_cols);

    return garden;
}

void print_garden_parcels(Garden garden)
{
    int rows = return_rows();
    int columns = return_columns();

    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < columns; ++j)
        {
            printf("\nThis is the parcel in position (%d, %d)\n", i, j);
            printf("Current production: %d\n", garden[i][j].production);
            printf("Price per unit: %f\n", garden[i][j].price_per_unit);
            printf("Necessary tools number: %d\n\n", garden[i][j].required_tools_num);

            for (int q = 0; q < garden[i][j].required_tools_num; q++)
            {
                printf("Tool %d\n\n", q + 1);
                printf("Serial number: %d\n", garden[i][j].tools[q].serial_number);
                printf("Category: %d\n", garden[i][j].tools[q].category);
                printf("Functional? %d\n", garden[i][j].tools[q].is_operational);
            }

            printf("\nFertilizer\n\n");
            printf("ID: %d\n", garden[i][j].fertilizer.id);
            printf("Name: %s\n", garden[i][j].fertilizer.name);
            printf("Inflammable?: %d\n", garden[i][j].fertilizer.is_flammable);
            printf("Quantity in kg: %d\n", garden[i][j].fertilizer_kg);
        }
    }
}

Garden modify_garden_parcels()
{
    int option = 0;
    Garden garden;

    do
    {
        printf("\n\t1. Add row/column");
        printf("\n\t2. Subtract row/column\n\n");
        printf("Enter your choice: ");

        int result = scanf("%d", &option);

        if(result != 1 || option < 1 || option > 2)
        {
            printf("\nERROR: That's not a valid option, try again...\n");
            while (getchar() != '\n');
        }
        else
        {
            int options = 0;

            if(option == 1)
            {
                do
                {
                    printf("\nDo you want to add columns or rows (1/2)?\n");
                    printf("Enter your choice: ");
                    int result2 = scanf("%d", &options);

                    if (result2 != 1 || options < 1 || options > 2)
                    {
                        printf("\nERROR: That's not a valid option, try again...\n");
                        while (getchar() != '\n');
                    }
                    else
                    {
                        int many = 0;

                        do
                        {
                            printf("\nFinally, how many?\n");
                            printf("Enter your choice: ");
                            int result3 = scanf("%d", &many);

                            if (result3 != 1 || many < 1)
                            {
                                printf("\nERROR: That's not a valid option, try again...\n");
                                while (getchar() != '\n');
                            }
                            else
                            {
                                return garden = resize_garden(option, options, many);
                            }
                        }
                        while (many < 1);
                    }
                }
                while (options < 1 || options > 2);
            }
            else if(option == 2)
            {
                do
                {
                    printf("\nDo you want to remove columns or rows (1/2)?\n");
                    printf("Enter your choice: ");
                    int result2 = scanf("%d", &options);

                    if (result2 != 1 || options < 1 || options > 2)
                    {
                        printf("\nERROR: That's not a valid option, try again...\n");
                        while (getchar() != '\n');
                    }
                    else
                    {
                        int many = 0;

                        do
                        {
                            printf("\nFinally, how many?\n");
                            printf("Enter your choice: ");
                            int result3 = scanf("%d", &many);

                            if (result3 != 1 || many < 1)
                            {
                                printf("\nERROR: That's not a valid option, try again...\n");
                                while (getchar() != '\n');
                            }
                            else
                            {
                                return garden = resize_garden(option, options, many);
                            }
                        }
                        while (many < 1);
                    }
                }
                while (options < 1 || options > 2);
            }
        }
    }
    while(option < 1 || option > 2);

	return 0;
}
