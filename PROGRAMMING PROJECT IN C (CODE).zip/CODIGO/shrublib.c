#include "shrublib.h"
#include "check_parcels.h"

Garden garden;
Garden new;
int columns;
int rows;

Garden add_column_row(int column_row, int number_of_lines)
{
	int i = 0;

	if (column_row == 1)
    {
        new = (Parcel **) malloc(sizeof(Parcel *) * rows);

		//Case where we are adding new columns
		for (i = 0; i < rows; i++)
        {
            new[i] = (Parcel *) malloc(sizeof(Parcel) * (columns + number_of_lines));

            for(int q = 0; q < columns; q++)
            {
                memcpy(&new[i][q], &garden[i][q], sizeof(Parcel));
            }

            for (int j = columns; j < columns + number_of_lines; j++)
            {
                new[i][j].pos_x = i;
                new[i][j].pos_y = j;
                fill_garden(i, j);
            }

            free(garden[i]);
		}

        columns += number_of_lines;
    }
    else
    {
		//Case where we are adding new rows
		new = (Parcel **) malloc(sizeof(Parcel *) * (rows + number_of_lines));

        for(i = 0; i < rows; i++)
        {
            new[i] = (Parcel *) malloc(sizeof(Parcel) * columns);
            memcpy(new[i], garden[i], sizeof(Parcel) * columns);
        }

        for (i = rows; i < number_of_lines + rows; i++)
        {
            new[i] = (Parcel *) malloc(sizeof(Parcel) * columns);
            memset(new[i], 0, sizeof(Parcel) * columns);

            for(int j = 0; j < columns; j++)
            {
                new[i][j].pos_x = i;
                new[i][j].pos_y = j;
                fill_garden(i, j);
            }
        }

        rows += number_of_lines;
    }

    garden = new;

    return garden;
}	

Garden subtract_column_row(int column_row, int number_of_lines)
{
	int i = 0;

	if (column_row == 1)
    {
		if(columns > 0 && number_of_lines <= columns)
		{
			for (i = 0; i < rows; i++)
        	{

            	for(int j = columns - number_of_lines; j < columns; j++)
            	{
                	free(garden[i][j].tools);
            	}

            	memmove(garden[i] + columns - number_of_lines, garden[i], (columns - number_of_lines) * sizeof(Parcel));
				garden[i] = (Parcel *) realloc(garden[i], (columns - number_of_lines) * sizeof(Parcel));
			}

        	columns -= number_of_lines;
		}
		else
		{
			printf("\nThere's no columns\n");
		}
    }
    else
    {
		if(rows > 0 && number_of_lines <= rows)
		{
        	Garden new = (Parcel **) malloc(sizeof(Parcel *) * (rows));

        	for(int i = 0; i < rows - number_of_lines; i++)
        	{
            	new[i] = garden[i];
        	}

        	for(i = rows - number_of_lines; i < rows; i++)
        	{
            	for(int j = 0; j < columns; j++)
            	{
                	free(garden[i][j].tools);
            	}

            	free(garden[i]);
        	}

        	rows -= number_of_lines;

        	for(i = 0; i < rows; i++)
        	{
            	new[i] = garden[i];
        	}

        	free(garden);
        	garden = new;
		}
		else
		{
			printf("\nThere's no rows\n");
		}
    }

    return garden;
}

Garden create_garden(int option_rows, int option_cols)
{
    int i, j, k;

    columns = option_cols;
    rows = option_rows;

    garden = (Parcel **) malloc (sizeof(Parcel *) * rows);

    Parcel **parcels = (Parcel **)malloc(sizeof(Parcel *) * rows);

    for (i = 0; i < rows; i++)
    {
        parcels[i] = (Parcel *) malloc(sizeof(Parcel) * columns);

        for(j = 0; j < columns; j++)
        {
            printf("\nEnter information for parcel in position (%d, %d)\n", i, j);
            parcels[i][j].pos_x = i;
            parcels[i][j].pos_y = j;

            printf("\nEnter the parcel's production: ");
            int production = 0;
            scanf("%d", &production);
            int checked_production = control_production(production);
            parcels[i][j].production = checked_production;

            printf("\nEnter the parcel's price per unit: ");
            float price = 0;
            scanf("%f", &price);
            float checked_price = control_price(price);
            parcels[i][j].price_per_unit = checked_price;

            printf("\nEnter the parcel's required tools number: ");
            int required_tools_num = 0;
            scanf("%d", &required_tools_num);
            int checked_required_tools_num = control_num_tools(required_tools_num);
            parcels[i][j].required_tools_num = checked_required_tools_num;

            parcels[i][j].tools = (Tool *) malloc(sizeof(Tool) * parcels[i][j].required_tools_num);

            for(k = 0; k < parcels[i][j].required_tools_num; k++)
            {
                printf("\nEnter the tool's serial number: ");
                int serial_number = 0;
                scanf("%d", &serial_number);
                parcels[i][j].tools[k].serial_number = serial_number;
                printf("\nEnter the tool's category: ");
                int category = 0;
                scanf("%d", &category);
                int checked_category = control_tool_cat(category);
                parcels[i][j].tools[k].category = checked_category;
                printf("\nEnter the tool's functional?: ");
                int functional = 0;
                scanf("%d", &functional);
                int check_func = control_tool_operation(functional);
                parcels[i][j].tools[k].is_operational = check_func;
            }

            printf("\nEnter the fertilizer's ID: ");
            int fertilizer_id = 0;
            scanf("%d", &fertilizer_id);
            parcels[i][j].fertilizer.id = fertilizer_id;
            printf("\nEnter the fertilizer's name: ");
            char fertilizer_name[50] = "";
            scanf("%s", fertilizer_name);
            strcpy(parcels[i][j].fertilizer.name, fertilizer_name);
            printf("\nEnter if fertilizer is inflammable?: ");
            int inflammable = 0;
            scanf("%d", &inflammable);
            int checked_inflammable = control_fert_inf(inflammable);
            parcels[i][j].fertilizer.is_flammable = checked_inflammable;
            printf("\nEnter fertilizer's quantity in kg: ");
            int quantity = 0;
            scanf("%d", &quantity);
            parcels[i][j].fertilizer_kg = quantity;
        }
    }

    garden = parcels;

    return garden;
}

Garden resize_garden(int add_subtract, int column_row, int number_of_lines)
{
	if (add_subtract == 1)
    {
		// If we want to add columns or rows
         return garden = add_column_row(column_row, number_of_lines);
	}
    else
    {
		// If we want to subtract columns or rows
		return garden = subtract_column_row(column_row, number_of_lines);
	}
}

Garden get_garden_info(int *num_rows, int *num_columns)
{
	
	// Fill the values of the dimensions woth the rows and columns that we have in our current garden
    //Error aqui
	*num_rows = rows;
	*num_columns = columns;

	// Return the current garden
	return garden;
}

int return_rows()
{
    int filas = 0;

    filas = rows;

    return filas;
}

int return_columns()
{
    int columnas = 0;

    columnas = columns;

    return columnas;
}

void fill_garden(int i, int j)
{
    float price = 0;
    printf("\nEnter information for parcel in position (%d, %d)\n", i, j);
    new[i][j].pos_x = i;
    new[i][j].pos_y = j;
    printf("\nEnter the parcel's production: ");
    scanf("%d", &new[i][j].production);
    printf("\nEnter the parcel's price per unit: ");
    scanf("%f", &price);
    new[i][j].price_per_unit = price;
    printf("\nEnter the parcel's required tools number: ");
    scanf("%d", &new[i][j].required_tools_num);
    new[i][j].tools = (Tool *) malloc(sizeof(Tool) * new[i][j].required_tools_num);

    for(int k = 0; k < new[i][j].required_tools_num; k++)
    {
        printf("\nEnter the tool's serial number: ");
        scanf("%d", &new[i][j].tools[k].serial_number);
        printf("\nEnter the tool's category: ");
        scanf("%d", &new[i][j].tools[k].category);
        printf("\nEnter the tool's functional?: ");
        scanf("%d", &new[i][j].tools[k].is_operational);
    }

    printf("\nEnter the fertilizer's ID: ");
    scanf("%d", &new[i][j].fertilizer.id);
    printf("\nEnter the fertilizer's name: ");
    scanf("%s", new[i][j].fertilizer.name);
    printf("\nEnter if fertilizer is inflammable?: ");
    scanf("%d", &new[i][j].fertilizer.is_flammable);
    printf("\nEnter fertilizer's quantity in kg: ");
    scanf("%d", &new[i][j].fertilizer_kg);
}
