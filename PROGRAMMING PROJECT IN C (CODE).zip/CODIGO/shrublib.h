#ifndef _SHRUBLIB_H_
#define _SHRUBLIB_H_

#define LITERS_PER_PARCEL 3
#define TRUE 1
#define FALSE 0
#define FERTILIZER_CATEGORIES 5
#define TOOL_CATEGORIES 7

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef struct
{
	int id;
	int is_flammable;
	char name[30];
} Fertilizer;

typedef struct
{
	int serial_number;
	int category;
	int is_operational;
} Tool;

typedef struct
{
    int pos_x;
	int pos_y;
	int production;
	float price_per_unit;
	int required_tools_num;
	Tool * tools;
	Fertilizer fertilizer;
	int fertilizer_kg;
} Parcel;

typedef Parcel** Garden;

/*
* This function creates a new garden with the characteristics specified
* with the parameters.
* Params: 
*	num_columns: how many columns should the garden matrix have.
* 	num_rows: How many rows should the garden matrix have.
*   garden_parcels: A matrix of parcels containing all the information 
*	for each parcel that forms the garden. They must be already initialized.
* Return: A Garden variable containing the created garden.
*/
Garden create_garden(int num_columns, int num_rows);

/*
* This procedure adds or deletes columns or rows to the previously created garden.
* Params: 
*	add_subtract: Indicates if we should add or subtract rows/columns
* 	column_row: Indicates if we should add/subtract columns or rows. 
*   number_of_lines: Tells us how many rows/columns should be added/subtracted 
*/
Garden resize_garden(int add_subtract, int column_row, int number_of_lines);

/*
* This function can be used to get all the necessary information related to the garden.
* Params: 
*	num_columns: how many columns does our garden currently have.
* 	num_rows: How many rows does our garden currently have.
* Return: A Garden variable containing the current status of the garden.
*/
Garden get_garden_info(int *num_rows, int *num_columns);

int return_rows();
int return_columns();
void fill_garden(int i, int j);
Garden subtract_column_row(int i, int j);
Garden add_column_row(int i, int j);


#endif
