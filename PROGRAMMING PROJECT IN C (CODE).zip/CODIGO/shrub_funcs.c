//
// Created by danie on 03/06/2023.
//
#include "shrub_funcs.h"
#include "shrublib.h"

void generate_shrub(Garden garden)
{
    int matolls = 0;
	int filas = return_rows();
    int colus = return_columns();

	for(int i = 0; i < filas; i++)
	{
		for(int j = 0; j < colus; j++)
		{
			if(j == 0 || i == filas - 1 || j == colus - 1 || i == 0)
			{
				if((i == 0 && j == colus - 1) || (i == 0 && j == 0))
				{
					matolls += 2;
				}
				else
				{
					matolls += 1;
				}
			}
		}
	}

	printf("\nWe will need  %d scrubs to cover this garden\n", matolls);
	start_roger(matolls);
}

void start_roger(int matolls)
{
	int option = 0;
	int exit = 0;
	int flag = 0;

	do
    {
        printf("\n\t1. Register and ask Roger for maintenance\n");
		printf("\t2. Add eccentric client\n");
		printf("\t3. List eccentric clients\n");
        printf("\t0. Exit\n\n");

        printf("What do you want to do? ");
        int result = scanf("%d", &option);

        if(result != 1 || option < 0 || option > 3)
        {
            printf("\nERROR: That's not a valid option, try again...\n\n");
            while (getchar() != '\n');
            flag = 1;
        }
        else
        {
            flag = 0;

            if(option == 1)
            {
                register_maint(matolls);
            }
			else if(option == 2)
			{
				add_ecclient();
			}
			else if(option == 3)
			{
				list_ecclients();
			}
            else if(option == 0)
            {
                printf("\nExiting shrub menu...\n");
                exit = 1;
            }
        }
    }
    while (flag == 1 || exit == 0);
}

void register_maint(int matolls)
{
	FILE *file;

	file = fopen(FILE_MAINT, "a");

	if(file == NULL)
	{
		printf("\nCouldn't open the file\n");
	}
	else
	{
		time_t actual = time(NULL);
		struct tm *fechas = localtime(&actual);

		fprintf(file, "Fecha y hora: %02d/%02d/%d %02d:%02d:%02d\n", fechas->tm_mday, fechas->tm_mon + 1, fechas->tm_year + 1900,
            fechas->tm_hour, fechas->tm_min, fechas->tm_sec);
    	fprintf(file, "Parcelas con matorrales: %d\n\n", matolls);

		fclose(file);

		printf("\nMaintenance done and saved correctly\n");
	}
}

void add_ecclient()
{
   FILE *file;
    char name[MAX], lastname[MAX], mail[MAX], phone[MAX], arbusto[MAX];

   file = fopen(FILE_ECCLIENTS, "a");

   if (file == NULL)
   {
       printf("Error opening\n");
   }
   else
   {
       printf("\nAdd mayordomo's name: ");
       scanf("%s", name);
       printf("Add mayordomo's lastname: ");
       scanf("%s", lastname);
       printf("Add mayordomo's mail: ");
       scanf("%s", mail);
       printf("Add mayordomo's phone: ");
       scanf("%s", phone);
       printf("Add the client's favorite shrub: ");
       scanf("%s", arbusto);

       fprintf(file, "Name: %s\n", name);
       fprintf(file, "Lastname: %s\n", lastname);
       fprintf(file, "Mail: %s\n", mail);
       fprintf(file, "Phone: %s\n", phone);
       fprintf(file, "Favorite shrub: %s\n\n", arbusto);

       fclose(file);
       printf("\nClient saved correctly\n");
   }
}

void list_ecclients()
{
    FILE *f;
    char cliente[150];

    f = fopen(FILE_ECCLIENTS, "r");

    if(f == NULL)
    {
        printf("Couldn't open file\n");
    }
    else
    {
        printf("\nList of eccentric clients:\n\n");

        while (fgets(cliente, sizeof(cliente), f) != NULL)
        {
            printf("%s", cliente);
        }

        fclose(f);
    }
}


