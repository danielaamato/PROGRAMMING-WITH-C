//
// Created by danie on 03/06/2023.
//

#ifndef PPI_2223_JULY_G02_SHRUB_FUNCS_H
#define PPI_2223_JULY_G02_SHRUB_FUNCS_H

#define MAX 60
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "shrublib.h"
#define FILE_MAINT "maint_list.txt"
#define FILE_ECCLIENTS "ecclients.txt"

void generate_shrub();
void start_roger(int matolls);
void register_maint(int matolls);
void add_ecclient();
void list_ecclients();

#endif //PPI_2223_JULY_G02_SHRUB_FUNCS_H
