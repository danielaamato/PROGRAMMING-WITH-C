//
// Created by danie on 24/04/2023.
//

#ifndef PPI_2223_JULY_G02_SALES_FUNCS_H
#define PPI_2223_JULY_G02_SALES_FUNCS_H

#define FILE_CONTACTS "contacts_list.txt"
#define FILE_OFFERS "orders_list.txt"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "shrublib.h"
#define MAX 60

typedef struct
{
    char name[MAX];
    char lastname[MAX];
    char phone[MAX];
    char supermarket[MAX];
}Sales;

typedef struct
{
    int number;
    int price;
    int units;
    char contact_name[MAX];
}Offer;

void sales_menu();
void listSalesContacts();
void addSaleContact();
int verifyContactPhone(Sales s);
int saveContact(Sales a);
void makeOffer(Garden garden);
void checkProductiveCapacity(Garden garden);
Sales verifyOfferPhone(char number[MAX]);
void acceptOffer(Sales contact, int units, int price);

#endif //PPI_2223_JULY_G02_SALES_FUNCS_H
