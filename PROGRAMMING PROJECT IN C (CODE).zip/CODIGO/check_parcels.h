//
// Created by danie on 17/04/2023.
//

#ifndef PPI_2223_JULY_G02_CHECK_PARCELS_H
#define PPI_2223_JULY_G02_CHECK_PARCELS_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int control_production(int prod);
float control_price(float price);
int control_num_tools(int num_tools);
int control_tool_cat(int cats);
int control_tool_operation(int oper);
int control_fert_inf(int fert_inf);

#endif //PPI_2223_JULY_G02_CHECK_PARCELS_H
