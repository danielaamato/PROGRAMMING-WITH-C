//
// Created by danie on 01/04/2023.
//

#ifndef PPI_2223_JULY_G02_USER_REGISTER_H
#define PPI_2223_JULY_G02_USER_REGISTER_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX 60
#define FILE_USERS "users_list.txt"

typedef struct {
    char username[MAX];
    char name[MAX];
    char password[MAX];
    char email[150];
} User;

int verifyEmailAndUsername(User userAux);
int saveUser(User user);
User existsLogin(char username_log[MAX], char password_log[MAX]);
User registerUser();
User loginUser();
void listUserInfo(User userAuxTwo);

#endif //PPI_2223_JULY_G02_USER_REGISTER_H
