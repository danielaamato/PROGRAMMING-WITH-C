//
// Created by danie on 06/04/2023.
//
#include "user_register.h"

int verifyEmailAndUsername(User userAux)
{
    FILE *f;
    User user;

    f = fopen(FILE_USERS, "a+");

    if(f == NULL)
    {
        printf("Couldn't open the file.\n\n");
    }
    else
    {
        rewind(f);
        while (fscanf(f, "%s %s %s %s", user.username, user.email, user.password, user.name) == 4)
        {
            if (strcmp(user.username, userAux.username) == 0 || strcmp(user.email, userAux.email) == 0)
            {
                fclose(f);
                return 1;
            }
        }

        fclose(f);

        return 0;
    }

    return 1;
}

int saveUser(User user)
{
    FILE *f;

    f = fopen(FILE_USERS, "a+");

    if(f == NULL)
    {
        printf("Couldn't open the file.\n\n");

        return 0;
    }
    else
    {
        fprintf(f, "\n%s %s %s %s", user.username, user.email, user.password, user.name);
    }

    fclose(f);

    return 1;
}

User existsLogin(char username[MAX], char password[MAX])
{
    FILE *f;
    User userAux;
    User notExist;

    f = fopen(FILE_USERS, "a+");

    if(f == NULL)
    {
        printf("Couldn't open the file.\n\n");
    }
    else
    {
        rewind(f);
        while (fscanf(f, "%s %s %s %s", userAux.username, userAux.email, userAux.password, userAux.name) == 4)
        {
            if (strcmp(userAux.username, username) == 0 && strcmp(userAux.password, password) == 0)
            {
                fclose(f);
                return userAux;
            }
        }

        strcpy(notExist.username, "null");

        fclose(f);

        return notExist;
    }

    strcpy(notExist.username, "null");

    return notExist;
}

User registerUser()
{
    User user;
    int flag2 = 0;
    int option = 0;
    User ret;

    printf("\nRegister New User\n");

    do
    {
        printf("\n\t1. Enter new user\n\n");
        printf("\t0. Back\n\n");

        printf("What do you want to do? ");
        int result = scanf("%d", &option);

        if (result != 1 || option < 0 || option > 1)
        {
            printf("\nERROR: That's not a valid option, try again...\n");
            while (getchar() != '\n');
            flag2 = 1;
        }
        else
        {
            flag2 = 0;
        }
    }
    while(flag2 == 1);

    if(option == 0)
    {
        strcpy(ret.username, "null");
        return ret;
    }
    else
    {
        do
        {
            printf("\nUsername: ");
            scanf("%s", user.username);

            printf("Name: ");
            scanf("%s", user.name);

            printf("Email: ");
            scanf("%s", user.email);

            printf("Password: ");
            scanf("%s", user.password);


            if (verifyEmailAndUsername(user))
            {
                printf("\nThe user already exists, try again with another...\n");
            }
            else
            {
                if (saveUser(user))
                {
                    ret = user;
                    printf("\nUser registered correctly, welcome %s.\n", user.name);
                    return ret;
                }
            }
        }
        while (1);
    }
}

User loginUser()
{
    char username[MAX], password[MAX];
    int flag2 = 0;
    int option;
    User user;

    printf("\nLogin User\n");

        do
        {
            printf("\n\t1. Enter credentials\n\n");
            printf("\t0. Back\n\n");

            printf("What do you want to do? ");
            int result = scanf("%d", &option);

            if (result != 1 || option < 0 || option > 1)
            {
                printf("\nERROR: That's not a valid option, try again...\n");
                while (getchar() != '\n');
                flag2 = 1;
            }
            else
            {
                flag2 = 0;
            }
        }
        while(flag2 == 1);

        if(option == 0)
        {
            strcpy(user.username, "null");
            return user;
        }
        else
        {
            do
            {
                printf("\nEnter username: ");
                scanf("%s", username);
                printf("Enter password: ");
                scanf("%s", password);

                user = existsLogin(username, password);

                if (strcmp(user.username, "null") != 0)
                {
                    printf("\nThe user is correct, welcome again %s!\n", username);
                    return user;
                }
                else
                {
                    printf("\nThat is not a valid login, try again...\n");
                }
            }
            while (1);
        }
}

void listUserInfo(User userAuxTwo)
{
    printf("\nShow user's information: \n\n");

    printf("\tUser's login username --- %s\n", userAuxTwo.username);
    printf("\tUser's name --- %s\n", userAuxTwo.name);
    printf("\tUser's email address --- %s\n", userAuxTwo.email);
}
