//
// Created by danie on 29/03/2023.
//
#include "user_register.h"
#include "garden_funcs.h"
#include "sales_funcs.h"
#include "shrub_funcs.h"
#include <stdio.h>
#define MAX 60
Garden aux;

void menuUser(User user)
{
    int option = 0;
    int exit = 0;
    int flag = 0;

    aux = initialize_garden();

    do
    {
        printf("\n\t1. Show user information\n");
        printf("\t2. List garden information\n");
        printf("\t3. Resize garden\n");
        printf("\t4. Sales Management\n");
        printf("\t5. Shrubberies stand options\n");
        printf("\t0. Exit\n\n");

        printf("What do you want to do? ");
        int result = scanf("%d", &option);

        if(result != 1 || option < 0 || option > 5)
        {
            printf("\nERROR: That's not a valid option, try again...\n\n");
            while (getchar() != '\n');
            flag = 1;
        }
        else
        {
            flag = 0;

            if(option == 1)
            {
                listUserInfo(user);
            }
            else if(option == 2)
            {
                print_garden_parcels(aux);
            }
            else if(option == 3)
            {
                aux = modify_garden_parcels();
            }
            else if(option == 4)
            {
                sales_menu(aux);
            }
            else if(option == 5)
            {
                generate_shrub(aux);
            }
            else if(option == 0)
            {
                printf("\nExiting menu...\n");
                exit = 1;
            }
        }
    }
    while (flag == 1 || exit == 0);
}

int mainMenu()
{
    int option = 0;

    do
    {
        printf("\n\t1. Register new user\n");
        printf("\t2. Login\n");
        printf("\t3. Logout\n\n");

        printf("What do you want to do? ");
        int result = scanf("%d", &option);

        if(result != 1 || option < 1 || option > 3)
        {
            printf("\nERROR: That's not a valid option, try again...\n");
            while (getchar() != '\n');
        }
    }
    while (option < 1 || option > 3);

    return option;
}

void selectMenu()
{
    int option = 0;
    User user;

    do
    {
        option = mainMenu();

        switch (option) {
            case 1:
                user = registerUser();

                if(strcmp(user.username, "null") == 0)
                {
                    selectMenu();
                }
                else
                {
                    menuUser(user);
                }

                break;

            case 2:
                user = loginUser();

                if(strcmp(user.username, "null") == 0)
                {
                    selectMenu();
                }
                else
                {
                    menuUser(user);
                }

                break;

            case 3:
                printf("\nUntil next time!\n");
                break;
        }
    }
    while(option != 3);
}

int main()
{
    printf("Welcome to ShrubberiesMore\n");

    selectMenu();

    return 0;
}
