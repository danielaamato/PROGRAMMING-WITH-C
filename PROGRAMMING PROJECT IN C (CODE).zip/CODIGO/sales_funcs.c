//
// Created by danie on 24/04/2023.
//
#include "sales_funcs.h"
#include "garden_funcs.h"
#include "shrublib.h"

void sales_menu(Garden garden)
{
    int option = 0;
    int exit = 0;
    int flag = 0;

    do
    {
        printf("\n\t1. List sales contacts\n");
        printf("\t2. Add sale contact\n");
        printf("\t3. Make an offer\n");
        printf("\t4. Check productive capacity\n");
        printf("\t0. Exit\n\n");

        printf("What do you want to do? ");
        int result = scanf("%d", &option);

        if(result != 1 || option < 0 || option > 4)
        {
            printf("\nERROR: That's not a valid option, try again...\n");
            while (getchar() != '\n');
            flag = 1;
        }
        else
        {
            flag = 0;

            if(option == 1)
            {
                listSalesContacts();
            }
            else if(option == 2)
            {
                addSaleContact();
            }
            else if(option == 3)
            {
                makeOffer(garden);
            }
            else if(option == 4)
            {
                checkProductiveCapacity(garden);
            }
            else if(option == 0)
            {
                printf("\nExiting sales menu...\n");
                exit = 1;
            }
        }
    }
    while (flag == 1 || exit == 0);
}

void addSaleContact()
{
    Sales new;
    int flag = 0;

    printf("\nAdd new sales contact: \n\n");

    do
    {
        printf("Name: ");
        scanf("%s", new.name);

        printf("LastName: ");
        scanf("%s", new.lastname);

        printf("Phone Number: ");
        scanf("%s", new.phone);

        printf("Supermarket: ");
        scanf("%s", new.supermarket);

        if (verifyContactPhone(new))
        {
            printf("\nThe contact already exists, try again with another...\n\n");
        }
        else
        {
            if (saveContact(new))
            {
                printf("\nContact registered correctly.\n");
                flag = 1;
            }
        }
    }
    while (flag == 0);
}

void listSalesContacts()
{
    printf("\nListing all sales contacts...\n\n");

    FILE *f;
    Sales contact;

    f = fopen(FILE_CONTACTS, "a+");

    if(f == NULL)
    {
        printf("Couldn't open the file.\n\n");
    }
    else
    {
        rewind(f);
        int cont = 1;

        while (fscanf(f, "%s %s %s %s", contact.name, contact.lastname, contact.phone, contact.supermarket) == 4)
        {
            printf("\t%d. %s %s %s %s\n", cont, contact.name, contact.lastname, contact.phone, contact.supermarket);
            cont++;
        }

        fclose(f);
    }
}

int verifyContactPhone(Sales contact)
{
    FILE *f;
    Sales old;

    f = fopen(FILE_CONTACTS, "a+");

    if(f == NULL)
    {
        printf("Couldn't open the file.\n\n");
    }
    else
    {
        rewind(f);
        while (fscanf(f, "%s %s %s %s", old.name, old.lastname, old.phone, old.supermarket) == 4)
        {
            if (strcmp(old.phone, contact.phone) == 0)
            {
                fclose(f);
                return 1;
            }
        }

        fclose(f);

        return 0;
    }

    return 1;
}

Sales verifyOfferPhone(char number[MAX])
{
    FILE *f;
    Sales old;
    Sales new;

    strcpy(new.phone, "wrong");

    f = fopen(FILE_CONTACTS, "a+");

    if(f == NULL)
    {
        printf("Couldn't open the file.\n\n");
    }
    else
    {
        rewind(f);
        while (fscanf(f, "%s %s %s %s", old.name, old.lastname, old.phone, old.supermarket) == 4)
        {
            if (strcmp(old.phone, number) == 0)
            {
                return old;
            }
        }

        fclose(f);
    }

    return new;
}

int saveContact(Sales contact)
{
    FILE *f;

    f = fopen(FILE_CONTACTS, "a+");

    if(f == NULL)
    {
        printf("Couldn't open the file.\n\n");

        return 0;
    }
    else
    {
        fprintf(f, "\n%s %s %s %s", contact.name, contact.lastname, contact.phone, contact.supermarket);
    }

    fclose(f);

    return 1;
}

void makeOffer(Garden garden)
{
    int total_prod_price = 0;
    int total_units = 0;
    int medium_price = 0;

    printf("\nMaking an offer: \n\n");

    int i = return_rows();
    int j = return_columns();

    for (int rows = 0; rows < i; rows++)
    {
        for(int columns = 0; columns < j; columns++)
        {
            total_prod_price += (garden[rows][columns].production * garden[rows][columns].price_per_unit);
            total_units += garden[rows][columns].production;
            medium_price +=  (garden[rows][columns].production * garden[rows][columns].price_per_unit) / garden[rows][columns].production;
        }
    }

    printf("Total production price: %d\n", total_prod_price);
    printf("Total units: %d\n", total_units);
    printf("Medium production price: %d\n\n", medium_price);
}

void checkProductiveCapacity(Garden garden)
{
    int units = 0;
    int price = 0;
    int total_prod_price = 0;
    int total_units = 0;
    char sales[MAX];

    printf("\nChecking productive capacity: \n\n");


    printf("How many units do you want to check? ");
    scanf("%d", &units);
    printf("How much are you willing to pay? ");
    scanf("%d", &price);

    int i = return_rows();
    int j = return_columns();

    for (int rows = 0; rows < i; rows++)
    {
        for(int columns = 0; columns < j; columns++)
        {
            total_prod_price += (garden[rows][columns].production * garden[rows][columns].price_per_unit);
            total_units += garden[rows][columns].production;
        }
    }

    if(total_units >= units)
    {
        if(total_prod_price <= price)
        {
            printf("\nWhat's the phone number of the sales contact? ");
            scanf("%s", sales);

            Sales contact = verifyOfferPhone(sales);

            if(strcmp(contact.phone, "wrong") != 0)
            {
                printf("\nThe garden has the capability to accept this offer.\n\n");
                acceptOffer(contact, units, price);
            }
            else
            {
                printf("\nThe contact does not exist...\n");
            }
        }
        else
        {
            printf("\nThe production is too expensive for this offer.\n");
        }
    }
    else
    {
        printf("\nYou don't have enough units to make an offer.\n");
    }
}

void acceptOffer(Sales contact, int units, int price)
{
    printf("Accepting offer...\n");

    FILE *f;
    int cont = 0;

    Offer offer;
    offer.price = price;
    offer.units = units;
    strcpy(offer.contact_name, contact.name);

    f = fopen(FILE_OFFERS, "a+");

    Offer old;

    if(f == NULL)
    {
        printf("Couldn't open the file.\n\n");
    }
    else
    {
        rewind(f);
        while(fscanf(f, "%d %d %d %s", &old.number, &old.price, &old.units, old.contact_name) == 4)
        {
            cont++;
        }

        cont++;

        offer.number = cont;
        fseek(f, 0, SEEK_END);
        fprintf(f, "\n%d %d %d %s", offer.number, offer.price, offer.units, offer.contact_name);
    }

    printf("\nOffer saved and accepted!\n");

    fclose(f);
}


