//
// Created by danie on 12/04/2023.
//

#ifndef PPI_2223_JULY_G02_GARDEN_FUNCS_H
#define PPI_2223_JULY_G02_GARDEN_FUNCS_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "shrublib.h"

#define MAX 60

void print_garden_parcels(Garden garden);
Garden initialize_garden();
Garden modify_garden_parcels();

#endif //PPI_2223_JULY_G02_GARDEN_FUNCS_H
